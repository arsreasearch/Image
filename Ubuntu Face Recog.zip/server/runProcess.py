from keras import models
from keras import layers
from keras import optimizers
from keras.preprocessing import image
from keras import backend
import numpy as np
import os
from keras.applications import VGG16


def getName():
    backend.clear_session()
    vgg_conv = VGG16(weights='imagenet',
                  include_top=False,
                  input_shape=(200,200,3))

    dirCount = 0
    for (dirpath, dirnames, filenames) in os.walk('fcog/images/train'):
        for d in dirnames:
            dirCount+=1

    testLabel = []

    with open('empno.txt') as my_file:
        for line in my_file:
            testLabel.append(line)

    model = models.Sequential()
    model.add(layers.Dense(512, activation='relu', input_dim=6 * 6 * 512))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(testLabel.__len__(), activation='softmax'))

    model.compile(optimizer=optimizers.RMSprop(lr=2e-4),
                loss='categorical_crossentropy',
                metrics=['acc'])
    model.load_weights('weights.h5')
    datagen = image.ImageDataGenerator(rescale=1./255)
    batch_size=1
    nVal = 1
    validation_features = np.zeros(shape=(nVal, 6, 6, 512))

    validation_dir='./fcog/currentpic'

    validation_generator = datagen.flow_from_directory(
        validation_dir,
        target_size=(200, 200),
        batch_size=batch_size,
        class_mode='categorical',
        shuffle=False)

    i = 0
    for inputs_batch, labels_batch in validation_generator:
        features_batch = vgg_conv.predict(inputs_batch)
        validation_features[i * batch_size : (i + 1) * batch_size] = features_batch
        i += 1
        if i * batch_size >= nVal:
            break

    

    validation_features = np.reshape(validation_features, (nVal, 6 * 6 * 512))
    predictions = model.predict_classes(validation_features)
    prob = model.predict(validation_features)

    return testLabel[np.argmax(prob[0])]

