import argparse
import asyncio
import json
import logging
import os
import ssl
import uuid
import shutil
import string
import random

import cv2
import numpy as np
import dlib
import glob
from scipy.spatial import distance
from imutils import face_utils
from keras.models import load_model
from fr_utils import *
from inception_blocks_v2 import *
from aiohttp import web
from av import VideoFrame
from databaseutils import getEmployee,getAllEmployees, updateStatus
from create_face import main
from runProcess import getName
from train import start_train
from imutils.face_utils import FaceAligner

from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack
from aiortc.contrib.media import MediaBlackhole, MediaPlayer, MediaRecorder

loop = asyncio.get_event_loop()
ROOT = os.path.dirname(__file__)

logger = logging.getLogger("pc")
pcs = set()

detector = dlib.get_frontal_face_detector()
user = {}
sentMessage = {}
FRmodel = load_model('face-rec_Google.h5')
print("Total Params:", FRmodel.count_params())
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
face_aligner = FaceAligner(predictor, desiredFaceWidth=200)
thresh = 0.25


class VideoTransformTrack(VideoStreamTrack):
    def __init__(self, track):
        super().__init__()  # don't forget this!
        self.track = track
        (lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
        (rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]
        self.lStart = lStart
        self.lEnd = lEnd
        self.rStart = rStart
        self.rEnd = rEnd
    
    async def recv(self):
        frame = await self.track.recv()
        hasFace = False
        img = frame.to_ndarray(format="bgr24")
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        subjects = detector(gray, 0)
        print(len(sentMessage))
        if len(sentMessage) > 0 or len(user) > 0:
            sentMessage.clear()
            print('sentMessage cleared')
            return web.Response(
                content_type="application/json",
            )
        for subject in subjects:
            shape = predictor(gray, subject)
            shape = face_utils.shape_to_np(shape)  # converting to NumPy Array
            leftEye = shape[self.lStart:self.lEnd]

            rightEye = shape[self.rStart:self.rEnd]
            #cv2.drawContours(img, [leftEyeHull], -1, (0, 255, 0), 1)
            #cv2.drawContours(img, [rightEyeHull], -1, (0, 255, 0), 1)
            faces = detector(img_rgb)
            x, y, w, h = 0, 0, 0, 0
            if len(faces) == 1:
                face = faces[0]
                hasFace = True
                (x, y, w, h) = face_utils.rect_to_bb(face)
                #cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 0), 2)
                
                face_img = gray[y-50:y + h+100, x-50:x + w+100]
                face_aligned = face_aligner.align(img, gray, face)

                face_img = face_aligned
                cv2.imwrite('./fcog/currentpic/1/image.jpg',face_img)
                val = getName()
                res = getEmployee(val)
                
                print(res[0])
                # user.update({'data' : data})
                user.update({'empNo' : res[0]})
                user.update({'fname' : res[1]})
                user.update({'lname' : res[2]})
                user.update({'status': res[3]})
            # rebuild a VideoFrame, preserving timing information
            new_frame = VideoFrame.from_ndarray(img, format="bgr24")
            new_frame.pts = frame.pts
            new_frame.time_base = frame.time_base
            return new_frame
        else:
            return frame

    
async def login(request):
    params = await request.json()
    emp_no = params['emp_no']
    status = params['status']
    updateStatus(emp_no,status)
    return web.Response(content_type="application/javascript",)
    
async def addTrain(request):
    params = await request.json()
    emp_no = params['emp_no']
    img_dir = './fcog/currentpic/1/image.jpg'
    img_path = 'fcog/images/train/'+emp_no+'/'+randomStringDigits(10)+'.jpg'
    shutil.copy(img_dir,img_path)
    return web.Response(content_type="application/javascript",)

def randomStringDigits(stringLength=10):
    """Generate a random string of letters and digits """
    lettersAndDigits = string.ascii_letters + string.digits
    return ''.join(random.choice(lettersAndDigits) for i in range(stringLength))

async def getEmployees(request):
    res = json.dumps(getAllEmployees())
    print(res)
    return web.Response(
        content_type="application/json",
        text=json.dumps(res),
    )

async def index(request):
    content = open(os.path.join(ROOT, "index.html"), "r").read()
    return web.Response(content_type="text/html", text=content)


async def javascript(request):
    content = open(os.path.join(ROOT, "client.js"), "r").read()
    return web.Response(content_type="application/javascript", text=content)

# async def save_image(request):
#     params = await request.json()
#     emp_no = params["emp_no"]
async def add_employee(request):
    print('!')
    params = await request.json()
    print('OMGS!!')
    fname = params['fname']
    lname = params['lname']
    emp_no = params['emp_no']
    main(fname,lname,emp_no)
    return web.Response(
        content_type="application/json",
    )

async def train(request):
    start_train()
    return web.Response(
        content_type="application/json",
    )

async def offer(request):
    sentMessage.clear()
    user.clear()
    params = await request.json()
    offer = RTCSessionDescription(sdp=params["sdp"], type=params["type"])

    pc = RTCPeerConnection()
    pc_id = "PeerConnection(%s)" % uuid.uuid4()
    pcs.add(pc)

    def log_info(msg, *args):
        logger.info(pc_id + " " + msg, *args)

    log_info("Created for %s", request.remote)

    # prepare local media
    player = MediaPlayer(os.path.join(ROOT, "demo-instruct.wav"))
    if args.write_audio:
        recorder = MediaRecorder(args.write_audio)
    else:
        recorder = MediaBlackhole()

    @pc.on("datachannel")
    def on_datachannel(channel):
        @channel.on("message")
        def on_message(message):
            print(len(user))
            if len(user) > 0:
                channel.send(json.dumps(user))
                sentMessage.update({'didSend': True})
                user.clear()
                print('user cleared')

    @pc.on("iceconnectionstatechange")
    async def on_iceconnectionstatechange():
        log_info("ICE connection state is %s", pc.iceConnectionState)
        if pc.iceConnectionState == "failed":
            await pc.close()
            pcs.discard(pc)

    @pc.on("track")
    def on_track(track):
        log_info("Track %s received", track.kind)

        if track.kind == "audio":
            pc.addTrack(player.audio)
            recorder.addTrack(track)
        elif track.kind == "video":
            local_video = VideoTransformTrack(
                track
            )
            pc.addTrack(local_video)

        @track.on("ended")
        async def on_ended():
            log_info("Track %s ended", track.kind)
            await recorder.stop()

    # handle offer
    await pc.setRemoteDescription(offer)
    await recorder.start()

    # send answer
    answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)

    return web.Response(
        content_type="application/json",
        text=json.dumps(
            {"sdp": pc.localDescription.sdp, "type": pc.localDescription.type}
        ),
    )


async def on_shutdown(app):
    # close peer connections
    coros = [pc.close() for pc in pcs]
    await asyncio.gather(*coros)
    pcs.clear()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="WebRTC audio / video / data-channels demo"
    )
    parser.add_argument("--cert-file", help="SSL certificate file (for HTTPS)")
    parser.add_argument("--key-file", help="SSL key file (for HTTPS)")
    parser.add_argument(
        "--port", type=int, default=8080, help="Port for HTTP server (default: 8080)"
    )
    parser.add_argument("--verbose", "-v", action="count")
    parser.add_argument("--write-audio", help="Write received audio to a file")
    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    if args.cert_file:
        ssl_context = ssl.SSLContext()
        ssl_context.load_cert_chain(args.cert_file, args.key_file)
    else:
        ssl_context = None
    
    app = web.Application()
    app.on_shutdown.append(on_shutdown)
    app.router.add_get("/", index)
    app.router.add_get("/client.js", javascript)
    app.router.add_post("/addEmployee",add_employee)
    app.router.add_post("/login",login)
    app.router.add_get('/train',train)
    app.router.add_post("/offer", offer)
    app.router.add_get('/getAllEmployees',getEmployees)
    app.router.add_post("/addTrain",addTrain)
    app.router.add_static('/static/',path=os.path.join(ROOT, "static"))
    web.run_app(app, access_log=None, port=args.port, ssl_context=ssl_context)
