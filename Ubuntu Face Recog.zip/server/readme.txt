###########INSTALLATION###########
1. Install Libraries
	- pip install -r requirements.txt

2. Download:
	haarcascade_frontalface_default.xml
	-https://github.com/opencv/opencv/blob/master/data/haarcascades/haarcascade_frontalface_default.xml

	face-rec_Google.h5
	-https://github.com/akshaybahadur21/Facial-Recognition-using-Facenet/blob/master/face-rec_Google.h5

	shape_predictor_68_face_landmarks.dat
	-https://github.com/AKSHAYUBHAT/TensorFace/blob/master/openface/models/dlib/shape_predictor_68_face_landmarks.dat


2. Import frdb.sql schema
3. Run server.py
	- python server.py