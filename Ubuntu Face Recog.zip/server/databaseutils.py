import mysql.connector
from mysql.connector import errorcode

def connectDB():
    mydb = mysql.connector.connect(
        host='localhost',
        user='dbuser123',
        passwd='*usjr12345!',
        database='frdb'
    )
    return mydb

def createDatabase():
    mydb = mysql.connector.connect(
        host='localhost',
        user='dbuser123',
        passwd='*usjr12345!'
    )
    mycursor = mydb.cursor()
    TABLES = {}
    TABLES['employees']=(
        "CREATE TABLE employees ("
        "  emp_no int(11) NOT NULL,"
        "  first_name varchar(14) NOT NULL,"
        "  last_name varchar(16) NOT NULL,"
        "  isLogged bool NOT NULL,"
        "  PRIMARY KEY (`emp_no`)"
        ") ENGINE=InnoDB")
    TABLES['logs'] = (
        "CREATE TABLE logs ("
        "   log_id int(11) NOT NULL AUTO_INCREMENT,"
        "   message varchar(255) NOT NULL,"
        "   datetime datetime,"
        "   PRIMARY KEY (log_id)"
        ") ENGINE=InnoDB")

    try:
        mycursor.execute("CREATE DATABASE frdb")
        
    except mysql.connector.Error as err:
        print("Failed Creating DB: {}".format(err))

    mydb.database = "frdb"

    mycursor = mydb.cursor()

    
    for table_name in TABLES:
        table_description = TABLES[table_name]
        try:
            print("Creating Table {}: ".format(table_name),end='')
            print(table_description)
            mycursor.execute(table_description)
        except mysql.connector.Error as err:
            if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
                print("already exists.")
            else:
                print(err.msg)
        else:
            print("OK")

    mycursor.close()

def registerEmployee(fname,lname,emp_no):
    query = "INSERT INTO employees(emp_no,first_name,last_name,isLogged) values(%s,%s,%s,false)"
    args=(emp_no,fname,lname)
    mydb = connectDB()
    mycursor = mydb.cursor()
    mycursor.execute(query,args)
    mydb.commit()
    print("Successfully Registered Employee")
    mycursor.close()
    mydb.close()

def getEmployee(emp_no):
    query = "SELECT * FROM employees WHERE emp_no = %s"
    mydb = connectDB()
    mycursor = mydb.cursor()
    mycursor.execute(query,(emp_no,))
    employee = mycursor.fetchone()
    mycursor.close()
    mydb.close()
    print(employee)
    return employee

def getAllEmployees():
    query = "SELECT * FROM employees"
    mydb = connectDB()
    mycursor = mydb.cursor()
    mycursor.execute(query)
    employees = mycursor.fetchall()
    mycursor.close()
    mydb.close()
    return employees

def updateStatus(emp_no,status):
    query = "UPDATE employees SET isLogged = %s WHERE emp_no = %s"
    mydb = connectDB()
    mycursor = mydb.cursor()
    mycursor.execute(query,(status,emp_no))
    mydb.commit()
    print(mycursor.rowcount, " record(s) affected")
